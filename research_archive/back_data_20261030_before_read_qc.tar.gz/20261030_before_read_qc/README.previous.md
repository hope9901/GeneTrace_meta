# GeneTrace — Evidence before evolutionary claims

Meta Global AI Developer Hackathon / Indie Dev Track를 위한 비교유전체 연구 보조 에이전트입니다. 실제 BLAST 기반 분석 baseline, 공개 데이터 대조군과 전체 유전자 orthology 분석 워크플로를 구현했습니다. Meta API 연동과 그룹 결과를 바탕으로 추가 검사를 선택하는 에이전트는 아직 구현하지 않았습니다.

## 전체 유전자 기반 비교로 확장

현재 범위는 소수 유전자 파일럿에서 **균주 중복 제거 후 전체 유전체·전체 단백질 코딩 유전자 분석**으로 확장했습니다. 435개 등록에서 156개 중복을 정리한 279개 대표 assembly의 원본 genome·GFF·CDS·protein을 확보했고, 1,541,009개 코딩 유전자 단위의 입력을 준비했습니다.

OrthoFinder 3.2의 64 core + 215 additional 워크플로로 전체 279개를 포함하는 계산을 실행 중입니다. [수집·중복 제거·분석 방법](docs/ALL_GENE_ORTHOLOGY.md)을 참고하세요. 실제 진행 상태는 `outputs/orthology_20261030/orthofinder_status.json`에 기록됩니다. 전체 orthogroup 결과는 계산과 유전자 수 검증이 끝나기 전까지 완료로 간주하지 않습니다.

병행 검사에서는 같은 BioSample의 대체 assembly 23쌍, 279개 전체의 annotation 범위, 실제 유전체 5개의 고정 64-locus 패널과 주변 유전자 배치를 점검했습니다. 주석 범위 누락, 검색 설정에 따른 미검출, frameshift가 기록된 모델을 서로 구분한 [초기 검증 결과](docs/LOSS_VS_ARTIFACT_TESTS.md)를 참고하세요. 생물학적 소실은 아직 확정하지 않았습니다.

## 실행 가능한 첫 버전

Python 3.9+와 NCBI BLAST+를 사용합니다. 자세한 설치 및 해석은 [개발 안내](docs/DEVELOPMENT.md)를 참고하세요.

```sh
python3 scripts/download_data.py
python3 scripts/prepare_demo.py
python3 -m genetrace --dataset data/demo/annotation_removed --output runs/new-investigation
python3 -m unittest discover -s tests -v
```

입력 checksum, 실행 명령·도구 버전, 원시 alignment, 근거 ID와 보고서를 저장합니다. 출력 디렉터리는 새 경로를 사용해야 합니다. 현재 실행은 모델을 호출하지 않는 deterministic baseline으로 명시됩니다.

첫 데이터는 공개 S. cerevisiae S288C 기준 유전체(GCF_000146045.2)의 ACT1 주변 구간입니다. 서로 다른 종을 비교한 결과가 아니라 알려진 위치에서 주석 누락·갭·미검출을 점검하는 대조군입니다. ACT1 주석 제거 대조군에서 query coverage 99.2%, identity 100%의 translated hit를 검출했습니다.

추가로 NCBI Contig 수준의 **CLIB215(GCA_019394775.1)**, **KACC 30049(GCA_060154965.1)** 전체 유전체에서도 ACT1 상동 서열을 각각 identity 100%, query coverage 99.2%로 검출했습니다. 두 원본은 CDS 주석이 없어 주석 오류 판정은 수행하지 않았습니다. [실험 결과와 한계](docs/CONTIG_EXPERIMENT.md)를 참고하세요.

NCBI에서 GFF3·CDS·단백질 파일을 제공하는 435개 assembly의 기본 정보 표와 assembly level별 boxplot도 작성했습니다. GC%와 단백질 수는 MD5를 검증한 실제 FASTA에서 계산했습니다. [분석 방법](docs/GENOME_METADATA_ANALYSIS.md)과 `outputs/s_cerevisiae_20261030/`의 Excel·CSV·PNG·PDF를 참고하세요.

Sequencing 기술, assembly 방법·툴, structural annotation 툴·버전·원문 근거도 추가했습니다. [수집·분류 기준](docs/SEQUENCING_AND_METHODS.md)과 `outputs/s_cerevisiae_methods_20261030/`의 확장 Excel·CSV 및 sequencing별 boxplot을 참고하세요. 확인한 NCBI 원문에 명시되지 않은 항목은 N/A이며 기능 주석 도구는 포함하지 않습니다.

## 해결할 문제

유전자 주석에 기록이 없다고 해서 실제 생물학적 소실이라고 단정할 수는 없습니다. GeneTrace는 특정 유전자군의 결손 후보를 조사하고, 유전체 서열·주석·주변 유전자 정보를 연결해 연구자가 다음 검증을 결정하도록 돕습니다.

**한 문장 소개:** An AI investigation agent that checks whether a missing gene is truly absent or hidden by genome assembly and annotation artifacts.

## 해커톤 요건

사용자가 제공한 Participant Guide를 기준으로 합니다. 변경 사항은 공식 제출 페이지와 Discord에서 확인해야 합니다.

- 주제: Push the Frontier. 도메인 적용 측면에서는 Build for Your World에도 해당.
- Meta 모델을 실제 조사 워크플로에 사용.
- 공개 코드 저장소, 접근 가능한 데모 및 3분 데모 영상 준비.
- 행사 기간에 새로 만든 코드와 기능을 명확히 표시.
- 제출 마감: 2026-11-04 21:00 EST = **2026-11-05 11:00 KST**.
- 심사 비중: Impact 30%, Meta AI Tooling 25%, Technical Depth 20%, Demo 25%.

## MVP 범위

첫 버전은 유전자군 확장보다 **apparent gene loss 조사**에 집중합니다.

1. 사전 준비된 공개 데이터의 유전자군과 비교 대상 유전체 선택.
2. 기존 주석의 유전자 수 및 후보 결손 표시.
3. Meta 모델이 허용된 도구 중 다음 검사를 선택.
4. 실제 서열 도구가 검색·좌표·품질 정보를 계산.
5. 모델이 결과를 검토하고 추가 검사 또는 보류를 선택.
6. 근거 ID가 연결된 결과와 재실행 자료를 다운로드.

결과 범주:

- `annotation_gap_candidate`: 주석 밖에 상동 서열이 검출됨. 기능성 유전자임을 확정하지 않음.
- `assembly_limited`: 갭·contig 경계 등으로 판단이 제한됨.
- `loss_supported`: 보존된 주변 위치 등 추가 근거가 소실 가설을 지지함. 검색 음성만으로 부여하지 않음.
- `inconclusive`: 근거 부족 또는 상충.

유사서열·위유전자 가능성을 표시하고, 상동성 검출과 orthology·기능 확인을 구분합니다. 모델의 확신을 통계적 확률로 표시하지 않습니다.

## 공개 데이터 전략

- 작은 진핵 미생물 유전체를 우선 검토하고, 식물병리 연구와 연결되는 곰팡이 데이터를 우선 후보로 둡니다.
- 첫 목표는 가까운 관계의 공개 유전체 2~3개와 검증 가능한 유전자군 1개입니다. 종·accession은 파일 및 주석 품질 확인 후 확정합니다.
- 입력: genome FASTA, annotation GFF3, protein FASTA, reference protein sequence.
- 출처 accession, 버전, 다운로드 URL, 사용 조건, 파일 SHA-256을 manifest에 기록합니다.
- 실제 공개 원본을 이용한 사례와 의도적으로 주석을 제거한 대조군을 분리합니다.
- 대조군은 원본을 보존한 별도 파일로 생성하고 화면·영상·보고서에 controlled perturbation임을 표시합니다. 이것을 자연 발생한 오류의 발견으로 소개하지 않습니다.
- 대조군에는 정상 주석, 주석 누락, 갭으로 판단 불가, 상동 서열 미검출을 포함합니다. 미검출은 실제 소실의 정답으로 취급하지 않습니다.

## 구현 구성안

- 분석 및 API: Python. 파일 처리와 분석 실행을 우선 구축합니다.
- 도구 후보: BLAST+의 단백질 검색 및 translated genome search, GFF3 좌표 비교, gap/contig 경계 검사, 주변 유전자 비교.
- 화면: 분석 엔진 검증 후 결과 비교표, 조사 타임라인, 서열 좌표·근거 패널을 구현합니다. 프레임워크는 그때 결정합니다.
- Meta: Muse Spark를 조사 계획·도구 선택·근거 종합에 사용합니다. 모델 ID는 환경변수로 설정하고 실제 계정 접근성을 확인합니다.
- 실행 도구는 고정된 함수와 인자 검증을 사용합니다. 모델 출력으로 임의 shell 명령을 실행하지 않습니다.
- 도구 실패는 실패로 기록하고, 음성 검색 결과와 구분합니다.
- 조사 단계 수·시간·모델 토큰 한도를 설정합니다.
- API 키는 서버 환경변수에만 저장합니다.

### 에이전트 도구 계약 초안

| 도구 | 목적 | 필수 결과 |
|---|---|---|
| inspect_annotation | 주석 및 후보 수 확인 | 유전자 ID, 위치, 입력 파일 ID |
| search_proteome | 주석 단백질 내 상동 후보 검색 | identity, coverage, E-value, 서열 ID |
| search_genome | 주석되지 않은 유전체 위치 검색 | strand, 좌표, alignment, 검색 조건 |
| inspect_locus | 주변 주석·갭·경계 확인 | 주변 유전자, N 비율, contig 경계 거리 |
| compare_neighborhood | 가까운 유전체의 주변 배치 비교 | anchor 및 방향·순서, 불확실성 |
| export_evidence | 재실행 자료 생성 | manifest, commands, versions, raw outputs, report |

검색 임계값은 데이터 선정 후 명시합니다. 진핵 유전자의 intron 때문에 translated hit 하나를 완전한 유전자 모델로 해석하지 않습니다.

### 추적 및 재현성

모든 검사에 evidence ID를 부여합니다. 입력 checksum, 도구 버전, 실행 인자, 종료 코드, stdout/stderr, 원시 결과를 저장합니다. 모델 ID, 프롬프트 버전, 도구 호출과 응답도 저장합니다. 보고서는 evidence ID를 인용해야 하며 없는 ID는 검증에서 거부합니다. 모델 내부 사고 과정 대신 실행한 작업과 관찰된 근거를 표시합니다.

## 검증 기준

- 주석 제거 대조군에서 남아 있는 서열의 위치를 찾는가?
- 정상 주석 대조군을 누락 사례로 잘못 표시하지 않는가?
- gap·contig 경계와 도구 실패에서 판단을 보류하는가?
- 모든 핵심 보고서 주장에 실제 근거 ID가 연결되는가?
- 재실행 시 같은 입력과 도구 설정으로 분석 결과를 재현할 수 있는가?
- Meta 모델이 실제 도구 결과에 따라 검사 선택을 바꾸는가?
- 데모용 녹화·캐시 결과와 live 실행을 명확히 구분하는가?

## 일정 — 한국시간 기준

| 날짜 | 목표 |
|---|---|
| 10/30 | 데이터 후보·유전자군 선정, Meta 접근 확인, 입력 및 근거 형식 확정 |
| 10/31 | 공개 파일 고정, 대조군 생성, 실제 검색 도구 동작 |
| 11/01 | 검사 선택 → 실행 → 결과 검토 에이전트 연결 |
| 11/02 | 결과 화면, 좌표·근거 표시, 다운로드 |
| 11/03 | 검증 사례 실행, 실패 처리, 공개 저장소 문서화 |
| 11/04 | 기능 동결, 3분 영상·제출 설명 작성, 접근성 확인 및 제출 |
| 11/05 11:00 | 공식 마감. 이 시각까지 제출을 미루지 않음 |

## 3분 데모 구성

- 0:00–0:25: 유전자 수 표에서 보이는 결손과 연구상 해석 문제.
- 0:25–0:50: 공개 데이터·후보 선택. 대조군이라면 명시.
- 0:50–1:45: 에이전트가 검사를 선택하고 실제 검색 결과를 검토하는 흐름.
- 1:45–2:20: 주석에는 없지만 서열이 남은 사례와 판단을 보류하는 사례 비교.
- 2:20–2:45: 좌표·원시 결과·명령어가 연결된 근거 패키지.
- 2:45–3:00: 연구 활용, Meta 역할, 검증 범위와 한계.

## 지금 필요한 준비

- 참가자 계정의 Meta Model API 크레딧과 모델 접근성 확인. 키는 채팅이나 저장소에 붙이지 않고 로컬 환경에 설정.
- 실제 공개 데이터 선정 및 다운로드.
- 저장소 공개와 외부 데모 배포는 구현물이 준비된 후 진행.

## 참고 자료

- 참가 요건·심사·일정: 사용자가 제공한 Meta Global AI Developer Hackathon Participant Guide.
- Meta 공식 개요: https://dev.meta.ai/docs/overview
- 조립 품질과 유전자 수 오류에 관한 연구: Denton et al. (2014), https://doi.org/10.1371/journal.pcbi.1003998

Meta API 문서는 2026-10-30 확인했습니다. 실제 호출 성공 여부와 데이터 accession은 아직 검증하지 않았습니다.
