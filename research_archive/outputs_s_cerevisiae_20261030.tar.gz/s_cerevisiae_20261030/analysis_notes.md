# S. cerevisiae assembly metadata

435 assemblies tabulated; 434 Full-representation assemblies plotted.

| Assembly level | n | Median size (Mb) | Median GC (%) | Median proteins |
|---|---:|---:|---:|---:|
| All full genomes | 434 | 12.065 | 38.35 | 5,690.0 |
| Complete Genome | 18 | 11.918 | 38.17 | 5,556.5 |
| Chromosome | 113 | 12.489 | 38.48 | 5,412.0 |
| Scaffold | 95 | 11.953 | 38.35 | 5,722.0 |
| Contig | 208 | 11.997 | 38.34 | 5,719.0 |

Protein FASTA records differ from protein-coding gene counts in 103 assemblies.

## Definitions and scope

- Snapshot: 2026-10-30. One row per assembly; GenBank/RefSeq paired duplicates removed.
- All 435 assemblies are in the table; the primary plots and summaries use 434 Full-representation assemblies.
- Full representation differs from Complete Genome assembly level. Partial GCA_000091065.2 is excluded from plots.
- Plotted genome size is total length of all genomic FASTA records. GC% is 100*(G+C)/(A+C+G+T) over the same FASTA.
- NCBI summary genome size covers the primary assembly only. It is preserved separately; FASTA may include other units.
- Rounded NCBI GC% is preserved separately. N and other ambiguity codes are excluded from the recomputed GC denominator.
- Number of proteins is the actual protein.faa.gz record count, verified against the NCBI-published compressed-file MD5.
- Protein records are not necessarily unique protein sequences or protein-coding gene loci. Both counts are kept.
- Genome size is in bp and Mb (1 Mb = 1,000,000 bp). GC is stored on the 0–100 percent scale.
- No outlier removal or inferential significance test. Assemblies are not necessarily independent biological strains.
- Genome representation, assembly type and annotation provider may explain some heterogeneity; causality was not tested.
- All source assembly_type fields read haploid; this label is not an independent ploidy measurement.
- Contig count is NCBI primary-assembly metadata. FASTA sequence count/N50 are separate and may describe scaffolds.
- GCA_903819185.2 has 16 protein FASTA records despite Full representation. File availability does not imply comprehensive annotation.
- Boxplots are static images; regenerate the analysis to reflect changes in the metadata table.
