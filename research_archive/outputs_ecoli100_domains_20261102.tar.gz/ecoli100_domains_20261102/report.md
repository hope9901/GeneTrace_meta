# E. coli 100 proteomes: selected Pfam domain panel

All 100 proteomes were scanned with six fixed Pfam profiles using HMMER --cut_ga. Domain instances and proteins carrying domains are reported separately. Coverage >=70% marks near-complete instances; shorter GA-passing hits remain.

| Profile | Proteins carrying domain per assembly (min–max) | Domain instances (min–max) |
|---|---|---|
| PF00005 / ABC_tran | 77–86 | 94–105 |
| PF00072 / Response_reg | 36–40 | 36–40 |
| PF00512 / HisKA | 19–22 | 19–22 |
| PF02518 / HATPase_c | 33–35 | 33–35 |
| PF00069 / Pkinase | 0–2 | 0–2 |
| PF00076 / RRM_1 | 0–0 | 0–0 |

Counts are descriptive; shared domains do not establish orthology, copy-number variation, function, biological loss or sequencing error. Only six profiles were tested, not the whole Pfam database. No 100-genome six-frame ORF search or bacterial raw read validation was performed. Commands, HMMER version and input hashes are in per-assembly scan manifests.
