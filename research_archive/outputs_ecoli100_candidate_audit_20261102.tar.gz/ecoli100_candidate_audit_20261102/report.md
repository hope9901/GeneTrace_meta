# 대장균 전체 단백질 후보와 계통·주변 유전자 맥락

100개 487,647개 단백질 전부를 90% AA identity/80% 양방향 coverage 조건으로 묶었다. 9,233개 상동성 후보 그룹, 3,027개 single-copy 공통 그룹, 높은 빈도 그룹의 누락 조합 915건을 찾았다. 이는 확정 orthogroup 분석이 아니다. 모든 입력 단백질의 1회 배정을 확인했다.

공통 single-copy 후보 30개 단백질, 정렬 7,664 columns로 잠정 계통수를 만들었다. 재조합 보정·gene-tree reconciliation은 하지 않았으며 동일 단백질에서 생성한 계통수는 독립 검증이 아니다.

915건 중 작은 WGS run이 연결되는 표본을 우선하여 9건을 DNA 검색·양쪽 주변 유전자 검사로 확인했다. 이 선택은 편의 표본이며 검출 정확도 추정용이 아니다.

| Assembly | 유전자 | DNA identity | query coverage | 양쪽 주변 유전자 | 주석 disruption | 가까운 5개 중 단백질 그룹 누락 |
|---|---|---|---|---|---|
| GCF_013112335.1 | potE | 33.021 | 0.970 | False | False | 0/5 |
| GCF_013112335.1 | ybiU | 84.689 | 0.993 | True | False | 0/5 |
| GCF_013112335.1 | tonB | 98.755 | 1.000 | True | False | 0/5 |
| GCF_030908725.1 | ydeR | 97.826 | 0.826 | True | True | 0/5 |
| GCF_001558995.2 | qseC | 97.917 | 0.855 | False | False | 0/5 |
| GCF_001558995.2 | nimT | 99.635 | 0.697 | True | True | 0/5 |
| GCF_031588155.1 | uhpC | 98.892 | 0.822 | True | True | 0/5 |
| GCF_031588155.1 | nimT | 99.635 | 0.697 | True | True | 1/5 |
| GCF_030847535.1 | rpnB | 65.763 | 0.997 | False | False | 0/5 |

tonB는 DNA 상동 서열·단백질 주석이 존재해 단백질 클러스터 미검출을 유전자 소실로 해석할 수 없다. nimT는 frameshifted 주석을 갖고 있어 raw read와 전체 코딩 모델 재검증이 필요하다. 낮은 query coverage의 HSP는 전체 유전자 또는 deletion breakpoint를 뜻하지 않는다.

기술 조합 및 BioProject별 집계와 가장 가까운 5개 표본의 거리·그룹 상태는 context.json에 있다. 유의성 검정·계통 보정 회귀를 한 결과가 아니며 플랫폼 편향을 입증하지 않는다. raw read 결과는 ../ecoli100_raw_validation_20261102/에서 별도 기록한다. 모든 원인은 미해결로 남긴다.
